package com.controller;

import com.model.Customer;
import com.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping
public class CustomerController {



    @GetMapping("/Login" )
    public String getLogin() {
        System.out.println("Here LogIN loaded");
        return "LogIn_page";
    }
    @GetMapping("/Register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("customer", new Customer());
        return "Register_Page";
    }



    @Autowired
    private CustomerRepository customerRepository;
   @GetMapping("/Display")
    public List<Customer> getCustomer(){
    return this.customerRepository.findAll();
    }

    @GetMapping("/GetBalance")
    public String getBalance(){
       return "Balance";
    }
    @PostMapping("/process_register")
    public String processRegister(Customer user) {

        customerRepository.save(user);

        return "register_success";
    }
}
