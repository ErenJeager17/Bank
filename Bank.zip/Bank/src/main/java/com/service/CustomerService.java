package com.service;

import com.model.Customer;
import com.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;

public class CustomerService {

    @Autowired
    CustomerRepository repository;

    public CustomerService(CustomerRepository repository) {
        this.repository = repository;
    }

    public Customer RegisterUser(String name, String email, String password){
        if(email!=null && password !=null){
            Customer register = new Customer();
            register.setName(name);
            register.setEmail(email);
            register.setPassword(password);
            return repository.save(register);
        }else{
            return null;
        }
    }


}
