package com.controller;

import com.model.Customer;
import com.repository.CustomerRepository;
import com.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.service.CustomerService;

import java.util.List;


@Controller
public class CustomerController {

@Autowired
private CustomerService Service;

    public CustomerController(CustomerService service) {
        Service = service;
    }



    @GetMapping("/Register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("registration",new Customer());
        return "Register_Page.html";
    }

    @GetMapping("/Login" )
    public String getLogin(Model model) {
        model.addAttribute("LoginRequest",new Customer());
        return "LogIn_page.html";
    }

    @PostMapping("/Register")
    public String getRegister(@ModelAttribute Customer cust){
    System.out.println("RegistrationRequest"+cust);
    Customer custo =Service.RegisterUser(cust.getName(),cust.getEmail(),cust.getPassword());
    return custo == null ? "errorPage.html":"redirect/login";
    }

    @PostMapping("/Login")
    public String getLogIn(@ModelAttribute Customer cust,Model model){
        System.out.println("LogInRequest"+cust);
        Customer authenticate =Service.authenticate(cust.getEmail(),cust.getPassword());
        if(authenticate!=null){
            model.addAttribute("userLogin",authenticate.getName());
            return "home.html";
        }else{
            return "errorPage.html";
        }
    }

    @Autowired
    private CustomerRepository customerRepository;
   @GetMapping("/Display")
    public List<Customer> getCustomer(){
       return this.customerRepository.findAll();
    }

}
